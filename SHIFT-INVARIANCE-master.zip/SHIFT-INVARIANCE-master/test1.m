%% TEST UC-DLA

%% clear everything
close all;
clear;
clc;

% the code used omptoolbox, if you have it already comment this line!!!
addpath([pwd '/omptoolbox']);

%% clear everything
% dimension of space
n = 20;
% target sparsity
k0 = 3;
% number of kernels
L = 45;
% how many shifts of the kernels are used
howmanyshifts = 3;

%% the kernels
F = randn(n, L);
F(19:n, :) = 0;

% normalize
F = bsxfun(@rdivide, F, sqrt(sum(F.^2)));

% length of the dataset
N = 2000;

%% construct the dataset
index = 0;
x = zeros(n, k0);
Y = zeros(n, N);

% support of each item
supports = [];
repeatNumber = ceil(N*k0/L);
for i = 1:L
    supports = [supports i*ones(1, repeatNumber)];
end
supports = supports(randperm(length(supports)));

% potentially add noise
SNR = inf;

% build each item
for i = 1:N
    support = supports(1:k0);
    supports(1:k0) = [];
    for j = 1:k0
        shiftsize = randsample(0:howmanyshifts-1, 1);
        x(:, j) = circshift(F(:, support(j)), shiftsize);
    end

    y = round(-10 + (10+10).*rand(k0,1));
    y = awgn(y, SNR, 'measured');
    
    if (norm(x*y) < 10^(-8))
        i = i-1;
    else
        Y(:, i) = x*y;
    end
end

% get sizes
[n, N] = size(Y);
% shuffle
Y = Y(:, randsample(N, N));

%%
[Q2su, Ssu, errorQ2su, timeQ2su] = ucircdlasu(Y, k0, L);
figure
plot(F(:,1))
hold on
plot(Q2su(:,339))
figure
plot(Ssu(:,1))

%% check the recovery success
G2 = abs(F'*Q2su);
thesupport = 1:L;
manytimes = zeros(1, L);
found = [];
for i = 1:L
    [val, ind] = max(G2(i, :));
    % check for the 0.99 threshold
    if (val>0.99)
        thesupport = setdiff(thesupport, floor(ind/n)+1);
        found = [found i];
    end
end
% percentage of recovery
proc = (L - length(thesupport))/L*100;
%%
%% cbpdndl
% Set up cbpdndl parameters
lambda = 0.0001;
opt = [];
opt.Verbose = 1;
opt.MaxMainIter = 250;
opt.rho = 10*lambda;
opt.sigma = size(Y,3);
opt.AutoRho = 1;
opt.AutoRhoPeriod = 10;
opt.AutoSigma = 1;
opt.AutoSigmaPeriod = 10;
opt.XRelaxParam = 1.8;
opt.DRelaxParam = 1.8;

% Construct initial dictionary
D0 = zeros(n,1,L);
D0(1:n,1,:) = randn(n,1,L);
% Do dictionary learning
[D, X, optinf] = cbpdndl(D0, Y, lambda, opt);

% Compute reconstruction
Ry = ifft2(sum(bsxfun(@times, fft2(D, size(X,1), size(X,2)), fft2(X)),3), ...
           'symmetric');
figure
plot(Y(:))
hold on
plot(Ry(:))

DQ=zeros(20,45);
figure
plot(X(:,2))
for i=1:20
    DQ(i,:)=D(i,1,:);
end
ADQ=[];
for i=1:45
     ADQ= [ADQ,circulant(DQ(:,i))];
end
%% check the recovery success
G3 = abs(F'*ADQ);
thesupport3 = 1:L;
manytimes = zeros(1, L);
found3 = [];
for i = 1:L
    [val, ind] = max(G3(i, :));
    % check for the 0.99 threshold
    if (val>0.99)
        thesupport3 = setdiff(thesupport3, floor(ind/n)+1);
        found3 = [found3 i];
    end
end
% percentage of recovery
proc3 = (L - length(thesupport3))/L*100;