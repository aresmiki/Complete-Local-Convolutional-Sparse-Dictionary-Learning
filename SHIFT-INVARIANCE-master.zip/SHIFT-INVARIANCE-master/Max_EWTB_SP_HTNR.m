function [KE]=Max_EWTB_SP_HTNR(boundaries)
global f
global fg
N=length(f);
[ewt]=EWTLB(f,boundaries(1:2));
Y=ewt{1};
Ya=[];
npq=2000;
for i=1:floor(N/npq)
    Ya(:,i)=Y(((i-1)*npq+1):i*npq+0);
end
n=20;
L=1;
m = size(Ya,1)+1-n;
% [Dconvsu, Xuconvsu] = uconvdlasu(Ya,17, L, n, m); %�����ź�10
[Dconvsu, Xuconvsu] = uconvdlasu(Ya,13, L, n, m); %�����ź�10
Ruconvsu=Dconvsu*Xuconvsu;
Ry=Ruconvsu(:);
% ybs=abs(fft(abs(hilbert(Ry))))*2/N;
% KE= kurt(ybs(2:N/2),'kurt2'); 
% KE= kurt(Ry,'kurt2'); 
KE=cal_NEWHTNR(Ry,fg,6,5,10); %21 11
%  KE=cal_NEWHTNR(ewt{1},fg,6,16,13);
KE=-KE;
end