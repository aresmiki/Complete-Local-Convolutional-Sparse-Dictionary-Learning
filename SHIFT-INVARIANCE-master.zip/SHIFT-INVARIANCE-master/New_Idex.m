% new
%%
clc
clear all
close all
N=10000;
Fs=10000;
defect = struct('type', 'outer', 'num', 1, 'interval', 9.5/19);
parameters = struct('Fs', Fs, 'N', N, 'f_BPFO', 83.30, 'f_RF',10.29,...
    'RSF', 3000, 'cyclostationary', 1, 'SDSF', 1/100,...
    'D', 1, 'maxtheta', 0.35*pi, 'qn', 10/9, 'SNR', -6, 'PLOT', 0, 'Beta',2000);
[sx, x, t, parameters] = BearingSimulation(defect, parameters);
%%
%%
npq=2000;
n=20;
[In,SKE]=Step_Min_New_Index_Spare(sx,npq,n,floor(Fs/83.3),[6,18]);
figure
plot(SKE)
[Ry]=Get_Max_SpareRec(sx,npq,n,In);
figure
plot(sx)
hold on
plot(Ry)



