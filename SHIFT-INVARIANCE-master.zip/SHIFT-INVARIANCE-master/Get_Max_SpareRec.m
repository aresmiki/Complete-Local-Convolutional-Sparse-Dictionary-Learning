function [Ry]=Get_Max_SpareRec(IYa,npq,n,spare)
L=1;

N=length(IYa);
for i=1:floor(N/npq)
    Ya(:,i)=IYa(((i-1)*npq+1):i*npq+0);
end
m = size(Ya,1)+1-n;



[Dconvsu, Xuconvsu, errorDconvsu, timeUconvsu] = uconvdlasu(Ya, spare, L, n, m);
Ruconvsu=Dconvsu*Xuconvsu;
Ry=Ruconvsu(:);

end